//Global Variables
var gamestate="play";
var jungle,jungleimg;
var monkey,monkeyimg;
var stones,stoneimg;
var banana,bananaimg;
var invisibeground;
var score;
var bananagroup,stonegroup;
var edges;
var gameover,gameoverimage;
var restart,restartimg;
function preload(){
  jungleimg=loadImage("jungle.jpg");
  monkeyimg=loadAnimation("Monkey_03.png","Monkey_02.png","Monkey_01.png","Monkey_10.png","Monkey_09.png","Monkey_08.png","Monkey_07.png","Monkey_06.png","Monkey_05.png");
  stoneimg=loadImage("stone.png");
  bananaimg=loadImage("Banana.png");
  gameoverimage=loadImage("gameOver.png");
  score = 0;
  restartimg=loadImage("restart.png");
  
}


function setup() {
  createCanvas(600,300);
  jungle=createSprite(300,100,1,1);
  jungle.addAnimation("jungle",jungleimg);
  jungle.scale=1;
  monkey=createSprite(50,220,1,1);
  monkey.addAnimation("monkey",monkeyimg);
  monkey.scale=0.2;
  //monkey.collide(edges);
  invisibleground=createSprite(100,290,1000,1);
  gameover=createSprite(300,200,1,1);
  gameover.addAnimation("gameover",gameoverimage);
  gameover.visible=false;
  restart=createSprite(300,228,1,1);
  restart.addAnimation("restart",restartimg);
  
  restart.visible=false;
  restart.scale=0.5;
  
 bananagroup=new Group();
stonegroup=new Group();
}


function draw(){
 background(255);
  if(gamestate==="play"){
    jungle.velocityX = -7;
     if (jungle.x < 200){
      jungle.x = jungle.width/2;

     if(monkey.x<10){
  monkey.x=50;
  monkey.y=220;
  }
  
 
       if(monkey.collide(stonegroup)){
  monkey.destroy();  
       gamestate="gameover";
       }
  
  }
  }
  if(gamestate==="gameover"){
 jungle.velocityX=0;
    bananagroup.setLifetimeEach(-1);
    stonegroup.setLifetimeEach(-1);
    bananagroup.setVelocityXEach(0);
    stonegroup.setVelocityXEach(0);
    gameover.visible=true;
    restart.visible=true;
    if(mousePressedOver(restart)){
    reset();
    }
  }
  
  if(keyDown("space")){
  monkey.velocityY=-17;
  }
         monkey.velocityY=monkey.velocityY+1;
       if(monkey.collide(bananagroup)){
  bananagroup.destroyEach();
  monkey.velocityX=0;
  score=score+10;  
  }
 
  

 
  //if(monkey.collide(  
  monkey.collide(invisibleground);
  drawSprites();
  text("Score: "+ score, 500,50);
   
 
  stone();
  bananas();
}
function stone(){
  if(frameCount%60===0){
  stones=createSprite(500,252,11,1);
  stones.addImage("stone",stoneimg);
  stones.scale=0.2;
  stones.velocityX=-8;
  stonegroup.add(stones);
}
}
function bananas(){
if(frameCount%120===0){
banana=createSprite(400,230,1,1);
banana.addImage("banana",bananaimg);  
banana.scale=0.05;
banana.velocityX=-8;  
bananagroup.add(banana);
  if(frameCount%80===0){
  banana1=createSprite(400,200,1,1);
banana1.addImage("banana",bananaimg);  
banana1.scale=0.05;
banana1.velocityX=-8;  
bananagroup.add(banana1);  
  }
}
}
function reset(){
  gamestate="play";
  restart.visible=false;
  gameover.visible=false;
  bananagroup.destroyEach();
  stonegroup.destroyEach();
  monkey.addAnimation("monkey",monkeyimg);
  score=0;  
  
}